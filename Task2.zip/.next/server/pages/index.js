"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/index";
exports.ids = ["pages/index"];
exports.modules = {

/***/ "./components/child.tsx":
/*!******************************!*\
  !*** ./components/child.tsx ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"Child\": () => (/* binding */ Child)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n//TO BE SHARED WITH CANDIDATES FOR TROUBLESHOOTING\n\n\nconst Child = ({ callback  })=>{\n    const [input, setInput] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(\"\\uD83D\\uDC4B\");\n    const handleCallback = ()=>callback(input);\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n            className: \"flex items-center max-w-md m-20 bg-white rounded-lg \",\n            children: [\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                    className: \"w-full\",\n                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"input\", {\n                        type: \"text\",\n                        className: \"w-full px-4 py-1 text-gray-800 rounded-full focus:outline-none\",\n                        placeholder: \"Imput\",\n                        value: input,\n                        onChange: (event)=>setInput(event.target.value)\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\DeekshithRaveendran\\\\Documents\\\\react\\\\components\\\\child.tsx\",\n                        lineNumber: 14,\n                        columnNumber: 25\n                    }, undefined)\n                }, void 0, false, {\n                    fileName: \"C:\\\\Users\\\\DeekshithRaveendran\\\\Documents\\\\react\\\\components\\\\child.tsx\",\n                    lineNumber: 13,\n                    columnNumber: 21\n                }, undefined),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                        className: \"flex items-center bg-blue-500 justify-center w-12 h-12 text-white rounded-r-lg\",\n                        type: \"submit\",\n                        onClick: handleCallback,\n                        children: \"Sent\"\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\DeekshithRaveendran\\\\Documents\\\\react\\\\components\\\\child.tsx\",\n                        lineNumber: 23,\n                        columnNumber: 25\n                    }, undefined)\n                }, void 0, false, {\n                    fileName: \"C:\\\\Users\\\\DeekshithRaveendran\\\\Documents\\\\react\\\\components\\\\child.tsx\",\n                    lineNumber: 22,\n                    columnNumber: 21\n                }, undefined)\n            ]\n        }, void 0, true, {\n            fileName: \"C:\\\\Users\\\\DeekshithRaveendran\\\\Documents\\\\react\\\\components\\\\child.tsx\",\n            lineNumber: 12,\n            columnNumber: 17\n        }, undefined)\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\DeekshithRaveendran\\\\Documents\\\\react\\\\components\\\\child.tsx\",\n        lineNumber: 11,\n        columnNumber: 9\n    }, undefined);\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL2NoaWxkLnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBLGtEQUFrRDtBQUVsRDtBQUE4QjtBQUV2QixNQUFNQyxRQUFRLENBQUMsRUFBRUMsU0FBUSxFQUFtQixHQUFLO0lBQ3BELE1BQU0sQ0FBQ0MsT0FBT0MsU0FBUyxHQUFHSiwrQ0FBUUEsQ0FBQztJQUVuQyxNQUFNSyxpQkFBaUIsSUFBTUgsU0FBU0M7SUFFdEMscUJBQ0ksOERBQUNHO2tCQUNPLDRFQUFDQTtZQUFJQyxXQUFVOzs4QkFDWCw4REFBQ0Q7b0JBQUlDLFdBQVU7OEJBQ1gsNEVBQUNKO3dCQUNHSyxNQUFLO3dCQUNMRCxXQUFVO3dCQUNWRSxhQUFZO3dCQUNaQyxPQUFPUDt3QkFDUFEsVUFBVSxDQUFDQyxRQUFVUixTQUFTUSxNQUFNQyxNQUFNLENBQUNILEtBQUs7Ozs7Ozs7Ozs7OzhCQUd4RCw4REFBQ0o7OEJBQ0csNEVBQUNRO3dCQUNHUCxXQUFVO3dCQUNWQyxNQUFLO3dCQUNMTyxTQUFTVjtrQ0FDWjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQU96QixFQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vLy4vY29tcG9uZW50cy9jaGlsZC50c3g/ZWZiNCJdLCJzb3VyY2VzQ29udGVudCI6WyIvL1RPIEJFIFNIQVJFRCBXSVRIIENBTkRJREFURVMgRk9SIFRST1VCTEVTSE9PVElOR1xuXG5pbXBvcnQge3VzZVN0YXRlfSBmcm9tICdyZWFjdCdcblxuZXhwb3J0IGNvbnN0IENoaWxkID0gKHsgY2FsbGJhY2sgfSA6IHtjYWxsYmFjazphbnl9KSA9PiB7XG4gICAgY29uc3QgW2lucHV0LCBzZXRJbnB1dF0gPSB1c2VTdGF0ZSgn8J+RiycpXG5cbiAgICBjb25zdCBoYW5kbGVDYWxsYmFjayA9ICgpID0+IGNhbGxiYWNrKGlucHV0KVxuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiA+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBtYXgtdy1tZCBtLTIwIGJnLXdoaXRlIHJvdW5kZWQtbGcgXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMSB0ZXh0LWdyYXktODAwIHJvdW5kZWQtZnVsbCBmb2N1czpvdXRsaW5lLW5vbmVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiSW1wdXRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtpbnB1dH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRJbnB1dChldmVudC50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgYmctYmx1ZS01MDAganVzdGlmeS1jZW50ZXIgdy0xMiBoLTEyIHRleHQtd2hpdGUgcm91bmRlZC1yLWxnXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVDYWxsYmFja31cbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBTZW50XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgIClcbn0iXSwibmFtZXMiOlsidXNlU3RhdGUiLCJDaGlsZCIsImNhbGxiYWNrIiwiaW5wdXQiLCJzZXRJbnB1dCIsImhhbmRsZUNhbGxiYWNrIiwiZGl2IiwiY2xhc3NOYW1lIiwidHlwZSIsInBsYWNlaG9sZGVyIiwidmFsdWUiLCJvbkNoYW5nZSIsImV2ZW50IiwidGFyZ2V0IiwiYnV0dG9uIiwib25DbGljayJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./components/child.tsx\n");

/***/ }),

/***/ "./pages/index.tsx":
/*!*************************!*\
  !*** ./pages/index.tsx ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Home)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _components_child__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../components/child */ \"./components/child.tsx\");\n//TO BE SHARED WITH CANDIDATES FOR TROUBLESHOOTING\n\n\n\nfunction Home() {\n    const [output, setState] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(\"\\uD83D\\uDC4B\");\n    //const callblack = '👋'\n    const callback = (payload)=>{\n        setState(payload);\n    };\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        className: \"h-screen flex flex-col flex-center items-center justify-center bg-gray-300\",\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h1\", {\n                children: [\n                    \"Got: \",\n                    output,\n                    \" from child component\"\n                ]\n            }, void 0, true, {\n                fileName: \"C:\\\\Users\\\\DeekshithRaveendran\\\\Documents\\\\react\\\\pages\\\\index.tsx\",\n                lineNumber: 16,\n                columnNumber: 13\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_child__WEBPACK_IMPORTED_MODULE_2__.Child, {\n                callback: callback\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\DeekshithRaveendran\\\\Documents\\\\react\\\\pages\\\\index.tsx\",\n                lineNumber: 17,\n                columnNumber: 13\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"C:\\\\Users\\\\DeekshithRaveendran\\\\Documents\\\\react\\\\pages\\\\index.tsx\",\n        lineNumber: 15,\n        columnNumber: 9\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9pbmRleC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQUEsa0RBQWtEO0FBRWxEO0FBQWdDO0FBQ1c7QUFFNUIsU0FBU0UsT0FBTztJQUMzQixNQUFNLENBQUNDLFFBQVFDLFNBQVMsR0FBR0osK0NBQVFBLENBQVM7SUFDNUMsdUJBQXdCO0lBRXhCLE1BQU1LLFdBQVcsQ0FBQ0MsVUFBaUI7UUFDL0JGLFNBQVNFO0lBQ2I7SUFFQSxxQkFDSSw4REFBQ0M7UUFBSUMsV0FBVTs7MEJBQ1gsOERBQUNDOztvQkFBRztvQkFBTU47b0JBQU87Ozs7Ozs7MEJBQ2pCLDhEQUFDRixvREFBS0E7Z0JBQUNJLFVBQVVBOzs7Ozs7Ozs7Ozs7QUFHN0IsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovLy8uL3BhZ2VzL2luZGV4LnRzeD8wN2ZmIl0sInNvdXJjZXNDb250ZW50IjpbIi8vVE8gQkUgU0hBUkVEIFdJVEggQ0FORElEQVRFUyBGT1IgVFJPVUJMRVNIT09USU5HXG5cbmltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBDaGlsZCB9IGZyb20gJy4uL2NvbXBvbmVudHMvY2hpbGQnXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEhvbWUoKSB7XG4gICAgY29uc3QgW291dHB1dCwgc2V0U3RhdGVdID0gdXNlU3RhdGU8c3RyaW5nPign8J+RiycpXG4gICAgLy9jb25zdCBjYWxsYmxhY2sgPSAn8J+RiydcblxuICAgIGNvbnN0IGNhbGxiYWNrID0gKHBheWxvYWQ6IGFueSkgPT4ge1xuICAgICAgICBzZXRTdGF0ZShwYXlsb2FkKVxuICAgIH1cblxuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPSdoLXNjcmVlbiBmbGV4IGZsZXgtY29sIGZsZXgtY2VudGVyIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBiZy1ncmF5LTMwMCc+XG4gICAgICAgICAgICA8aDE+R290OiB7b3V0cHV0fSBmcm9tIGNoaWxkIGNvbXBvbmVudDwvaDE+XG4gICAgICAgICAgICA8Q2hpbGQgY2FsbGJhY2s9e2NhbGxiYWNrfSAvPlxuICAgICAgICA8L2Rpdj5cbiAgICApXG59Il0sIm5hbWVzIjpbInVzZVN0YXRlIiwiQ2hpbGQiLCJIb21lIiwib3V0cHV0Iiwic2V0U3RhdGUiLCJjYWxsYmFjayIsInBheWxvYWQiLCJkaXYiLCJjbGFzc05hbWUiLCJoMSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/index.tsx\n");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/index.tsx"));
module.exports = __webpack_exports__;

})();